const BaseMailer = require('./baseMailer')

class AuthMailer extends BaseMailer {
  constructor(senderAddress) {
    this.sender = senderAddress;
  }

	sendWelcomeEmail(recipient, subject, templateData, callback) {
		const email = {
			from: this.sender,
			to: recipient,
			subject: subject,
			context: templateData,
			template: welcomeEmail,
		}

		this.transporter.sendMail(email, callback);
	}
}

module.exports = AuthMailer;