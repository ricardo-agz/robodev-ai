const User = require('../models/user');
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");


const AuthController = {
  
  /*
   * login
   * url: /auth/login
   */
  login: async (req, res) => {
    try {
      const user = await User.findOne({ username: req.body.username });
      if (!user) {
        return res.status(400).send({ message: "Invalid username" });
      }
      const checkpassword = await bcrypt.compare(req.body.password, user.password);
      if (!checkpassword) {
        return res.status(400).send({ message: "Incorrect password" });
      }
      jwt.sign( { id: user._id.toString(), username: user.username }, 'PLEASE_CHANGE', {expiresIn: 86400},
          (err, token) => {
              if (err){
                    return res.status(500).send({ message: "Error generating token" });
              }
            return res.status(200).send({ id: user._id.toString(), token: 'Bearer ' + token });
          })
    } catch(e) {
      console.error(`server error in AuthController login() : ${e}`);
    };
  },

  /*
   * register
   * url: /auth/register
   */
  register: async (req, res) => {
    try {
      const user = req.body;
      const takenusername = await User.findOne({ username: user.username });
      const takenemail = await User.findOne({ email: user.email });
      if (takenUsername) {
        return res.status(500).send({ message: "Username already exists" });
      }
      if (takenEmail) {
        return res.status(500).send({ message: "Email already exists" });
      }
      const userpassword = await bcrypt.hash(req.body.password, 10);
      user.password = userpassword
      const dbUser = await new User({
        ...user,
      }).save((err, data) => {
        if (err) {
          return res.status(500).send({ message: "Error registering new user" });
        };
        return res.status(201).send({ data: data, message: 'Succesfully registered new account' });
      });
    } catch(e) {
      console.error(`server error in AuthController register() : ${e}`);
    };
  },


}

module.exports = AuthController;