const Comment = require('../models/comment');


const CommentController = {
  
  /*
   * index
   * url: /comments
   */
  index: async (req, res) => {
    try {
      const data = await Comment.find({});
      return res.status(200).send(data);
    } catch(e) {
      console.error(`server error in CommentController index() : ${e}`);
    };
  },

  /*
   * show
   * url: /comments/:id
   * params: ['id']
	 */
  show: async (req, res) => {
    try {
      const { id } = req.params;
      const data = await Comment.findById(id);
      return res.status(200).send(data);
    } catch(e) {
      console.error(`server error in CommentController show() : ${e}`);
    };
  },

  /*
   * create
   * url: /comments
   */
  create: async (req, res) => {
    try {
      const newData = await new Comment({
        content,
      }).save((err, data) => {
        if (err) {
          return res.status(500).send({ message: "Error creating new Comment" });
        };
        return res.status(200).send({ message: "New Comment was successfully created!" });
      });
    } catch(e) {
      console.error(`server error in CommentController create() : ${e}`);
    };
  },

  /*
   * update
   * url: /comments/:id
   * params: ['id']
	 */
  update: async (req, res) => {
    try {
      const { id } = req.params;
      const newData = await Comment.findByIdAndUpdate(id,
      {
        content,
      },
      (err, data) => {
        if (err) {
          return res.status(500).send({ message: "Error updating Comment" });
        };
        return res.status(200).send({ message: "Comment was successfully updated!" });
      });
    } catch(e) {
      console.error(`server error in CommentController update() : ${e}`);
    };
  },

  /*
   * delete
   * url: /comments/:id
   * params: ['id']
	 */
  delete: async (req, res) => {
    try {
      const { id } = req.params;
      const data = await Comment.findByIdAndDelete(id,
      (err, data) => {
        if (err) {
          return res.status(500).send({ message: "Error deleting Comment" });
        };
        return res.status(200).send({ message: "Comment was successfully deleted" });
      });
    } catch(e) {
      console.error(`server error in CommentController delete() : ${e}`);
    };
  },


}

module.exports = CommentController;