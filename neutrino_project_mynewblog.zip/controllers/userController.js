const User = require('../models/user');

const UserController = {
  
  /*
   * index
   * url: /users
   */
  index: async (req, res) => {
    try {
      const data = await User.find({});
      return res.status(200).send(data);
    } catch(e) {
      console.error(`server error in UserController index() : ${e}`);
    };
  },

  /*
   * show
   * url: /users/:id
   * params: ['id']
	 */
  show: async (req, res) => {
    try {
      const { id } = req.params;
      const data = await User.findById(id);
      return res.status(200).send(data);
    } catch(e) {
      console.error(`server error in UserController show() : ${e}`);
    };
  },

  /*
   * create
   * url: /users
   */
  create: async (req, res) => {
    try {
      const newData = await new User({
        name,
        email,
        password,
      }).save((err, data) => {
        if (err) {
          return res.status(500).send({ message: "Error creating new User" });
        };
        return res.status(200).send({ message: "New User was successfully created!" });
      });
    } catch(e) {
      console.error(`server error in UserController create() : ${e}`);
    };
  },

  /*
   * update
   * url: /users/:id
   * params: ['id']
	 */
  update: async (req, res) => {
    try {
      const { id } = req.params;
      const newData = await User.findByIdAndUpdate(id,
      {
        name,
        email,
        password,
      },
      (err, data) => {
        if (err) {
          return res.status(500).send({ message: "Error updating User" });
        };
        return res.status(200).send({ message: "User was successfully updated!" });
      });
    } catch(e) {
      console.error(`server error in UserController update() : ${e}`);
    };
  },

  /*
   * delete
   * url: /users/:id
   * params: ['id']
	 */
  delete: async (req, res) => {
    try {
      const { id } = req.params;
      const data = await User.findByIdAndDelete(id,
      (err, data) => {
        if (err) {
          return res.status(500).send({ message: "Error deleting User" });
        };
        return res.status(200).send({ message: "User was successfully deleted" });
      });
    } catch(e) {
      console.error(`server error in UserController delete() : ${e}`);
    };
  },


}

module.exports = UserController;