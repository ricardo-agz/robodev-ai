const express       = require('express');
const router        = express.Router();
module.exports      = router;

const UserController = require('../controllers/UserController');
const PostController = require('../controllers/PostController');
const CommentController = require('../controllers/CommentController');
const AuthController = require('../controllers/AuthController');
const { verifyJWT } = require('./middlewares');

// Home
router.get('/', (_req, res) => {
  res.status(200).send({ message: 'Welcome to Neutrino!' });
});

router.get('/users', verifyJWT, UserController.index);
router.get('/users/:id', verifyJWT, UserController.show);
router.post('/users', UserController.create);
router.put('/users/:id', verifyJWT, UserController.update);
router.delete('/users/:id', verifyJWT, UserController.delete);

router.get('/posts', PostController.index);
router.get('/posts/:id', verifyJWT, PostController.show);
router.post('/posts', verifyJWT, PostController.create);
router.put('/posts/:id', verifyJWT, PostController.update);
router.delete('/posts/:id', verifyJWT, PostController.delete);

router.get('/comments', verifyJWT, CommentController.index);
router.get('/comments/:id', verifyJWT, CommentController.show);
router.post('/comments', verifyJWT, CommentController.create);
router.put('/comments/:id', verifyJWT, CommentController.update);
router.delete('/comments/:id', verifyJWT, CommentController.delete);

router.post('/auth/login', AuthController.login);
router.post('/auth/register', AuthController.register);


// Default response for any other request
router.use((_req, res) => {
  res.status(404).send({ message: "404 not found" });
});