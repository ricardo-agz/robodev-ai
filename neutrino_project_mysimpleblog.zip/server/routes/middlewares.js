const User = require('../models/user');
const jwt = require("jsonwebtoken");
require('dotenv').config();

const verifyJWT = (req, res, next) => {
	    if (!req.headers['authorization']) {
	      return res.status(401).send({ message: "No Token Given" });
	    }
	    const token = req.headers['authorization'].split(' ')[1];
	    if (token) {
	      jwt.verify( token, PLEASE_CHANGE,
	            (err, decoded)=>{
	                if (err){
	                        return res.status(401).send({ message: "Failure to auth" });
	                }
	              req.user = {};
	              req.user.id = decoded.id;
	              req.user.username = decoded.username;
	              next();
	            })
	    } else {
	      return res.status(401).send({ message: "Invalid token given" });
	    };
	

}
module.exports = {
	verifyJWT
};