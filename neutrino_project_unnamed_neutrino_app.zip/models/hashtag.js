const mongoose = require('mongoose');

const HashtagSchema = new mongoose.Schema({
	name: {
		type: String,
		required: true
	},
	TaggedPosts: [
		{
			type: mongoose.Schema.Types.ObjectId,
			ref: 'Post'
		}
	],
});


const Hashtag = mongoose.model('Hashtag', HashtagSchema);
module.exports = Hashtag;
