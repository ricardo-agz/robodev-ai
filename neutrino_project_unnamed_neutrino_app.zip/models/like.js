const mongoose = require('mongoose');

const LikeSchema = new mongoose.Schema({
	user_id: {
		type: ObjectId,
		required: true
	},
	post_id: {
		type: ObjectId,
		required: true
	},
});


const Like = mongoose.model('Like', LikeSchema);
module.exports = Like;
