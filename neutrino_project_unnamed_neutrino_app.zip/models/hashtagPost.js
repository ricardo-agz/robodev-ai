const mongoose = require('mongoose');

const HashtagPostSchema = new mongoose.Schema({
	hashtag_id: {
		type: ObjectId,
		required: true
	},
	post_id: {
		type: ObjectId,
		required: true
	},
});


const HashtagPost = mongoose.model('HashtagPost', HashtagPostSchema);
module.exports = HashtagPost;
