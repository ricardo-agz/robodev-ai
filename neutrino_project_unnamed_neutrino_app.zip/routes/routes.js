const express       = require('express');
const router        = express.Router();
module.exports      = router;

const AuthController = require('../controllers/AuthController');
const UserController = require('../controllers/UserController');
const PostController = require('../controllers/PostController');

// Home
router.get('/', (_req, res) => {
  res.status(200).send({ message: 'Welcome to Neutrino!' });
});

router.post('/api/login', AuthController.login);
router.post('/api/register', AuthController.register);
router.post('/api/change-password/:user_id', AuthController.changePassword);

router.get('/api/-users', UserController.index);
router.get('/api/-users/:id', UserController.show);
router.put('/api/-users/:id', UserController.update);
router.delete('/api/-users/:id', UserController.delete);
router.post('/api/users/:follower_id/follow/:following_id', UserController.followUser);
router.delete('/api/users/:follower_id/unfollow/:following_id', UserController.unfollowUser);

router.get('/api/-posts', PostController.index);
router.get('/api/-posts/:id', PostController.show);
router.post('/api/-posts', PostController.create);
router.put('/api/-posts/:id', PostController.update);
router.delete('/api/-posts/:id', PostController.delete);
router.post('/api/posts/:post_id/users/:user_id/like', PostController.likePost);
router.delete('/api/posts/:post_id/users/:user_id/like', PostController.unlikePost);
router.post('/api/posts/:post_id/hashtags/:hashtag_id', PostController.tagPost);
router.delete('/api/-posts/:id', PostController.delete);


// Default response for any other request
router.use((_req, res) => {
  res.status(404).send({ message: "404 not found" });
});