const User = require('../models/user');


const UserController = {
  
  /*
   * index
   * url: /api/-users
   */
  index: async (req, res) => {
    try {
      const data = await User.find({});
      return res.status(200).send(data);
    } catch(e) {
      console.error(`server error in UserController index() : ${e}`);
    };
  },

  /*
   * show
   * url: /api/-users/:id
   * params: ['id']
	 */
  show: async (req, res) => {
    try {
      const { id } = req.params;
      const data = await User.findById({ _id: id });
      return res.status(200).send(data);
    } catch(e) {
      console.error(`server error in UserController show() : ${e}`);
    };
  },

  /*
   * update
   * url: /api/-users/:id
   * params: ['id']
	 */
  update: async (req, res) => {
    try {
      const { id } = req.params;
    } catch(e) {
      console.error(`server error in UserController update() : ${e}`);
    };
  },

  /*
   * delete
   * url: /api/-users/:id
   * params: ['id']
	 */
  delete: async (req, res) => {
    try {
      const { id } = req.params;
      const data = await User.findByIdAndDelete(id,
      (err, data) => {
        if (err) {
          return res.status(500).send({ message: "Error deleting User" });
        };
        return res.status(200).send({ message: "User was successfully deleted" });
      });
    } catch(e) {
      console.error(`server error in UserController delete() : ${e}`);
    };
  },

  /*
   * followUser
   * url: /api/users/:follower_id/follow/:following_id
   * params: ['follower_id', 'following_id']
	 */
  followUser: async (req, res) => {
    try {
      const { follower_id, following_id } = req.params;
      const follower = await User.findById({ _id: req.params.follower_id });
      return res.status(404).send({ message: "follower user not found" });
    } catch(e) {
      console.error(`server error in UserController followUser() : ${e}`);
    };
  },

  /*
   * unfollowUser
   * url: /api/users/:follower_id/unfollow/:following_id
   * params: ['follower_id', 'following_id']
	 */
  unfollowUser: async (req, res) => {
    try {
      const { follower_id, following_id } = req.params;
      const follower = await User.findById({ _id: req.params.follower_id });
      return res.status(404).send({ message: "follower user not found" });
    } catch(e) {
      console.error(`server error in UserController unfollowUser() : ${e}`);
    };
  },


}

module.exports = UserController;