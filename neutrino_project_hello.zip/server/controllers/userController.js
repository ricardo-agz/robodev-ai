const User = require('../models/user')
const Post = require('../models/post')

const UserController = {
  
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	addPost: async (req, res)=> {
	},
	dropPost: async (req, res)=> {
	},
	addUser: async (req, res)=> {
	},
	dropUser: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	addPost: async (req, res)=> {
	},
	dropPost: async (req, res)=> {
	},
	addUser: async (req, res)=> {
	},
	dropUser: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	addPost: async (req, res)=> {
	},
	dropPost: async (req, res)=> {
	},
	addUser: async (req, res)=> {
	},
	dropUser: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	addPost: async (req, res)=> {
	},
	dropPost: async (req, res)=> {
	},
	addUser: async (req, res)=> {
	},
	dropUser: async (req, res)=> {
	},

}

module.exports = UserController;