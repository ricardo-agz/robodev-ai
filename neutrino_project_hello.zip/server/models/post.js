const mongoose = require('mongoose');

const PostSchema = new mongoose.Schema({
	bio: {
		type: String,
		required: true
	},
	users: [
		{
			type: mongoose.Schema.Types.ObjectId,
			ref: 'User'
		}
	]
});

PostSchema.set('toObject', { virtuals: true });
PostSchema.set('toJSON', { virtuals: true });

const Post = mongoose.model('Post', PostSchema);
module.exports = Post;
