import React, { useContext, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { CircularProgress } from '@mui/material';
import { UserContext } from '../hooks/UserContext';

export default function PrivateRoute({ component }) {
  const [loading, setLoading] = useState(true);
  const { authUser, authLoading } = useContext(UserContext);

  if (authUser) return component
  else if (authLoading) return <CircularProgress />;
  else return <Navigate to="/login" />
}