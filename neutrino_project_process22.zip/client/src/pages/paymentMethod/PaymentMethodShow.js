import React from 'react';
import '../../App.css';
import axios from 'axios';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Button, CircularProgress } from '@mui/material';
import useApi from '../../hooks/useApi';
import authHeader from '../../services/auth-header';
import configData from '../../config.json'


export default function PaymentMethodShow(props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { result: paymentMethod, loading, error, refresh } = useApi(`${configData.SERVER_URL}/paymentmethods/${id}`);

  /*
   * Delete paymentmethod
   */
  function handleDelete() {
    axios.delete(`${configData.SERVER_URL}/paymentmethods/${id}`, { headers: authHeader() });
    axios.delete(`${configData.SERVER_URL}/paymentmethods/${id}`, { headers: authHeader() });
    navigate('/paymentmethods');
  }


  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !paymentMethod) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <div className='row'>
          <h1 className='paddedRight'>PaymentMethod {id}</h1>

          {/* EDIT */}
          <Button variant="outlined" style={{marginRight: 15}}
            onClick={() => navigate(`/paymentmethods/${id}/edit`)}>edit
          </Button>

          {/* DELETE */}
          <Button variant="contained" color="error" 
            onClick={handleDelete}>delete
          </Button>
        </div>

        <label>Card Number: {paymentMethod.card_number}</label>
        <label>Name: {paymentMethod.name}</label>
        <label>Expiration Date: {paymentMethod.expiration_date}</label>
        <label>CVV: {paymentMethod.CVV}</label>
        <label>User: {paymentMethod.user}</label>

        
      </div>
    );
  }
}
