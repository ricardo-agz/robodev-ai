import React, { useState } from 'react';
import '../../App.css';
import { useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';
import authHeader from '../../services/auth-header';
import configData from '../../config.json'

export default function PaymentMethodNew() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

	const handleSubmit = (card_number, name, expiration_date, CVV, user) => {
    setLoading(true);
    setError(null);
		axios.post(`${configData.SERVER_URL}/paymentmethods`, {
      card_number: card_number,
      name: name,
      expiration_date: expiration_date,
      CVV: CVV,
      user: user
    }, { headers: authHeader() })
    .then(_res => {
      navigate("/paymentmethods")
    })
    .catch(err => {
      setError(err.response.data.message);
    })
    .then(_res => {
      setLoading(false);
    })
	};

	return (
		<div className='container'>
			<h1>Edit Payment Method</h1>

      {/* ERROR DISPLAY */}
      { error &&
        <p style={{color: "red"}}>{error}</p>
      }

      {/* FORM DISPLAY */}
			<ValidatedForm
				loading={loading}
				submit={(card_number, name, expiration_date, CVV, user) =>
					handleSubmit(card_number, name, expiration_date, CVV, user)
				}
			/>
		</div>
	)
}
