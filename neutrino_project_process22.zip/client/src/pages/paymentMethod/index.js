export { default as PaymentMethods } from './PaymentMethods';
export { default as PaymentMethodShow } from './PaymentMethodShow';
export { default as PaymentMethodNew } from './PaymentMethodNew';
export { default as PaymentMethodEdit } from './PaymentMethodEdit';
