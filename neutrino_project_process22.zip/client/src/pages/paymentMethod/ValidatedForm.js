import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom';
import MuiAlert from '@mui/material/Alert';
import {
  Snackbar,
  TextField,
  Button,
  Checkbox,
  Stack
} from '@mui/material'

const Alert = React.forwardRef((props, ref) => {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

export default function ValidatedForm(props) {
  const { id } = useParams();
	const [card_number, setCardNumber] = useState(0);
	const [name, setName] = useState('');
	const [expiration_date, setExpirationDate] = useState('');
	const [CVV, setCVV] = useState(0);
	const [user, setUser] = useState(id ? id : '');
  const [err, setErr] = useState(null);                       // error message  
  const [openErr, setOpenErr] = useState(false);              // is error display open
  const [isLoading, setIsLoading] = useState(props.loading);  // awaiting result

  /* 
   * Update loading state when props changes 
   */
  useEffect(() => {
    setIsLoading(props.loading);
  }, [props.loading])

  /* 
   * Load default values if model passed and model is updated 
   */
  useEffect(() => {
		if (props.model) {
      setCardNumber(props.model.card_number);
      setName(props.model.name);
      setExpirationDate(props.model.expiration_date);
      setCVV(props.model.CVV);
      setUser(props.model.user);
		}
	}, [props.model]);

  /*
   * Ensure all required fields are not empty
   */
  const validate = () => {
		if (card_number !== '' && name !== '' && expiration_date !== '' && CVV !== '' && user !== '') {
			props.submit(card_number, name, expiration_date, CVV, user)
		} else {
			if (card_number === '') {
				setErr('card_number cannot be left blank')
			}
			else if (name === '') {
				setErr('name cannot be left blank')
			}
			else if (expiration_date === '') {
				setErr('expiration_date cannot be left blank')
			}
			else if (CVV === '') {
				setErr('CVV cannot be left blank')
			}
			else if (user === '') {
				setErr('user cannot be left blank')
			}
      setOpenErr(true)
    }
  }

  /* 
   * Close error snackbar
   */
  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenErr(false);
  };

  return (
    <div className='container'>
      <Stack spacing={3}>
				<TextField
					label='card_number' size='small' type='Number'
					value={card_number}
					onChange={(e) => setCardNumber(e.target.value)}
				/>
				<TextField
					label='name' size='small' type='String'
					value={name}
					onChange={(e) => setName(e.target.value)}
				/>
				<TextField
					label='expiration_date' size='small' type='String'
					value={expiration_date}
					onChange={(e) => setExpirationDate(e.target.value)}
				/>
				<TextField
					label='CVV' size='small' type='Number'
					value={CVV}
					onChange={(e) => setCVV(e.target.value)}
				/>
				<TextField
					label='user' size='small' type='String'
					value={user}
					onChange={(e) => setUser(e.target.value)}
				/>

        {/* SUBMIT */}
        <Button variant="contained" onClick={validate}>
          {isLoading ? "loading..." : "submit"}
        </Button>
      </Stack>

      {/* ERROR ALERT */}
      <Snackbar open={openErr} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>
          {err}
        </Alert>
      </Snackbar>
    </div>
  )
}