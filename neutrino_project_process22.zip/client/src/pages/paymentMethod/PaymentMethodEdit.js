import React, { useState, useEffect } from 'react';
import '../../App.css';
import { useParams, useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';
import useApi from '../../hooks/useApi';
import authHeader from '../../services/auth-header';
import { CircularProgress } from '@mui/material';
import configData from '../../config.json'

export default function PaymentMethodEdit() {
	const { id } = useParams();
  const navigate = useNavigate();
  const { result: paymentMethod, loading: paymentMethodLoading, error: fetchError, refresh } = useApi(`${configData.SERVER_URL}/paymentmethods/${id}`);
  const [editLoading, setEditLoading] = useState(false);
  const [editError, setEditError] = useState(null);

	const handleSubmit = (card_number, name, expiration_date, CVV, user) => {
    setEditLoading(true);
    setEditError(null);
    axios.put(`${configData.SERVER_URL}/paymentmethods/${id}/edit`, 
    {
      card_number: card_number,
      name: name,
      expiration_date: expiration_date,
      CVV: CVV,
      user: user
    }, { headers: authHeader() })
    .then(_res => {
      navigate(`/paymentmethods/${id}`)
    })
    .catch(err => {
      setEditError(err.response.data.message);
    })
    .then(_res => {
      setEditLoading(false);
    })
	};

	if (fetchError) {
		return <p style={{color: "red"}}>Error: {fetchError}</p>;
  } else if (paymentMethodLoading || !paymentMethod) {
		return <CircularProgress />;
	} else {
		return (
			<div className='container'>
				<h1>Edit Payment Method</h1>

        {/* ERROR DISPLAY */}
        { editError &&
          <p style={{color: "red"}}>{editError}</p>
        }

        {/* FORM DISPLAY */}
				<ValidatedForm
					model={paymentMethod}
					loading={editLoading}
					submit={(card_number, name, expiration_date, CVV, user) =>
						handleSubmit(card_number, name, expiration_date, CVV, user)
					}
				/>
			</div>
		)
	}
}
