import React, { useState } from 'react';
import '../../App.css';
import axios from 'axios';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Button, CircularProgress, ButtonGroup, TextField } from '@mui/material';
import useApi from '../../hooks/useApi';
import authHeader from '../../services/auth-header';
import configData from '../../config.json'


export default function WorkoutGroupShow(props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { result: workoutGroup, loading, error, refresh } = useApi(`${configData.SERVER_URL}/workoutgroups/${id}`);
	const [memberId, setMemberId] = useState();

  /*
   * Delete workoutgroup
   */
  function handleDelete() {
    axios.delete(`${configData.SERVER_URL}/workoutgroups/${id}`, { headers: authHeader() });
    axios.delete(`${configData.SERVER_URL}/workoutgroups/${id}`, { headers: authHeader() });
    navigate('/workoutgroups');
  }


  /*
   * Add member to workoutgroup's members list
   */ 
  function addMember() {
    try {
      axios.post(`${configData.SERVER_URL}/workoutgroups/${id}/add-member/${memberId}`,
				{}, { headers: authHeader() });
    } catch (e) {
      console.log(e);
    };
    window.location.reload();
  };

  /*
   * Drop member from workoutgroup's members list
   */ 
  function dropMember(droppedId) {
    try {
      axios.post(`${configData.SERVER_URL}/workoutgroups/${id}/drop-member/${droppedId}`,
				{}, { headers: authHeader() });
    } catch (e) {
      console.log(e);
    };
    window.location.reload();
  };

  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !workoutGroup) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <div className='row'>
          <h1 className='paddedRight'>WorkoutGroup {id}</h1>

          {/* EDIT */}
          <Button variant="outlined" style={{marginRight: 15}}
            onClick={() => navigate(`/workoutgroups/${id}/edit`)}>edit
          </Button>

          {/* DELETE */}
          <Button variant="contained" color="error" 
            onClick={handleDelete}>delete
          </Button>
        </div>

        <label>Name: {workoutGroup.name}</label>

        
        {/* Members*/}
        <div className='displayContainer'>
					<h3>Members</h3>

					<div className='row'>
						<TextField
							label='course id' size='small' style={{marginRight: 10}}
							onChange={(e) => { setMemberId(e.target.value) }}
						/>
						<Button 
              variant='contained' 
              onClick={addMember}
            >
              Add Member
            </Button>
					</div>

					<ul>
          {workoutGroup.members && workoutGroup.members.map((member, i) => (
						<div className='listItem' key={i}>
							<li>{member._id}</li>
							<ButtonGroup variant='outlined' size='small'>
								<Button onClick={() => navigate(`/users/${member}._id`)}>show</Button>
                <Button color='error' onClick={() => dropMember(member._id)}>drop</Button>
							</ButtonGroup>
						</div>
					))}
					</ul>
				</div>

      </div>
    );
  }
}
