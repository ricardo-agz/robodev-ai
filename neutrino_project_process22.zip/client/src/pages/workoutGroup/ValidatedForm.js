import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom';
import MuiAlert from '@mui/material/Alert';
import {
  Snackbar,
  TextField,
  Button,
  Checkbox,
  Stack
} from '@mui/material'

const Alert = React.forwardRef((props, ref) => {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

export default function ValidatedForm(props) {
  
	const [name, setName] = useState('');
  const [err, setErr] = useState(null);                       // error message  
  const [openErr, setOpenErr] = useState(false);              // is error display open
  const [isLoading, setIsLoading] = useState(props.loading);  // awaiting result

  /* 
   * Update loading state when props changes 
   */
  useEffect(() => {
    setIsLoading(props.loading);
  }, [props.loading])

  /* 
   * Load default values if model passed and model is updated 
   */
  useEffect(() => {
		if (props.model) {
      setName(props.model.name);
		}
	}, [props.model]);

  /*
   * Ensure all required fields are not empty
   */
  const validate = () => {
		if (name !== '') {
			props.submit(name)
		} else {
			if (name === '') {
				setErr('name cannot be left blank')
			}
      setOpenErr(true)
    }
  }

  /* 
   * Close error snackbar
   */
  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenErr(false);
  };

  return (
    <div className='container'>
      <Stack spacing={3}>
				<TextField
					label='name' size='small' type='String'
					value={name}
					onChange={(e) => setName(e.target.value)}
				/>

        {/* SUBMIT */}
        <Button variant="contained" onClick={validate}>
          {isLoading ? "loading..." : "submit"}
        </Button>
      </Stack>

      {/* ERROR ALERT */}
      <Snackbar open={openErr} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>
          {err}
        </Alert>
      </Snackbar>
    </div>
  )
}