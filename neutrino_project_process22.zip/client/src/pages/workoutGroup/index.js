export { default as WorkoutGroups } from './WorkoutGroups';
export { default as WorkoutGroupShow } from './WorkoutGroupShow';
export { default as WorkoutGroupNew } from './WorkoutGroupNew';
export { default as WorkoutGroupEdit } from './WorkoutGroupEdit';
