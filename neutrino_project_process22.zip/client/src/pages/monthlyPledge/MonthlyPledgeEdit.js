import React, { useState, useEffect } from 'react';
import '../../App.css';
import { useParams, useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';
import useApi from '../../hooks/useApi';
import authHeader from '../../services/auth-header';
import { CircularProgress } from '@mui/material';
import configData from '../../config.json'

export default function MonthlyPledgeEdit() {
	const { id } = useParams();
  const navigate = useNavigate();
  const { result: monthlyPledge, loading: monthlyPledgeLoading, error: fetchError, refresh } = useApi(`${configData.SERVER_URL}/monthlypledges/${id}`);
  const [editLoading, setEditLoading] = useState(false);
  const [editError, setEditError] = useState(null);

	const handleSubmit = (payment_amount, active, user) => {
    setEditLoading(true);
    setEditError(null);
    axios.put(`${configData.SERVER_URL}/monthlypledges/${id}/edit`, 
    {
      payment_amount: payment_amount,
      active: active,
      user: user
    }, { headers: authHeader() })
    .then(_res => {
      navigate(`/monthlypledges/${id}`)
    })
    .catch(err => {
      setEditError(err.response.data.message);
    })
    .then(_res => {
      setEditLoading(false);
    })
	};

	if (fetchError) {
		return <p style={{color: "red"}}>Error: {fetchError}</p>;
  } else if (monthlyPledgeLoading || !monthlyPledge) {
		return <CircularProgress />;
	} else {
		return (
			<div className='container'>
				<h1>Edit Monthly Pledge</h1>

        {/* ERROR DISPLAY */}
        { editError &&
          <p style={{color: "red"}}>{editError}</p>
        }

        {/* FORM DISPLAY */}
				<ValidatedForm
					model={monthlyPledge}
					loading={editLoading}
					submit={(payment_amount, active, user) =>
						handleSubmit(payment_amount, active, user)
					}
				/>
			</div>
		)
	}
}
