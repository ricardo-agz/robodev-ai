import React, { useState } from 'react';
import '../../App.css';
import { useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';
import authHeader from '../../services/auth-header';
import configData from '../../config.json'

export default function MonthlyPledgeNew() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

	const handleSubmit = (payment_amount, active, user) => {
    setLoading(true);
    setError(null);
		axios.post(`${configData.SERVER_URL}/monthlypledges`, {
      payment_amount: payment_amount,
      active: active,
      user: user
    }, { headers: authHeader() })
    .then(_res => {
      navigate("/monthlypledges")
    })
    .catch(err => {
      setError(err.response.data.message);
    })
    .then(_res => {
      setLoading(false);
    })
	};

	return (
		<div className='container'>
			<h1>Edit Monthly Pledge</h1>

      {/* ERROR DISPLAY */}
      { error &&
        <p style={{color: "red"}}>{error}</p>
      }

      {/* FORM DISPLAY */}
			<ValidatedForm
				loading={loading}
				submit={(payment_amount, active, user) =>
					handleSubmit(payment_amount, active, user)
				}
			/>
		</div>
	)
}
