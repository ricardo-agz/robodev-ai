import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom';
import MuiAlert from '@mui/material/Alert';
import {
  Snackbar,
  TextField,
  Button,
  Checkbox,
  Stack
} from '@mui/material'

const Alert = React.forwardRef((props, ref) => {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

export default function ValidatedForm(props) {
  const { id } = useParams();
	const [payment_amount, setPaymentAmount] = useState(0);
	const [active, setActive] = useState(false);
	const [user, setUser] = useState(id ? id : '');
  const [err, setErr] = useState(null);                       // error message  
  const [openErr, setOpenErr] = useState(false);              // is error display open
  const [isLoading, setIsLoading] = useState(props.loading);  // awaiting result

  /* 
   * Update loading state when props changes 
   */
  useEffect(() => {
    setIsLoading(props.loading);
  }, [props.loading])

  /* 
   * Load default values if model passed and model is updated 
   */
  useEffect(() => {
		if (props.model) {
      setPaymentAmount(props.model.payment_amount);
      setActive(props.model.active);
      setUser(props.model.user);
		}
	}, [props.model]);

  /*
   * Ensure all required fields are not empty
   */
  const validate = () => {
		if (payment_amount !== '' && active !== '' && user !== '') {
			props.submit(payment_amount, active, user)
		} else {
			if (payment_amount === '') {
				setErr('payment_amount cannot be left blank')
			}
			else if (active === '') {
				setErr('active cannot be left blank')
			}
			else if (user === '') {
				setErr('user cannot be left blank')
			}
      setOpenErr(true)
    }
  }

  /* 
   * Close error snackbar
   */
  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenErr(false);
  };

  return (
    <div className='container'>
      <Stack spacing={3}>
				<TextField
					label='payment_amount' size='small' type='Number'
					value={payment_amount}
					onChange={(e) => setPaymentAmount(e.target.value)}
				/>
				<div className='row'>
					<label>active:</label>
					<Checkbox 
						checked={active}
						defaultChecked 
						onChange={(e) => setActive(e.target.type === 'checkbox' ? e.target.checked : e.target.value)}
					/>
				</div>
				<TextField
					label='user' size='small' type='String'
					value={user}
					onChange={(e) => setUser(e.target.value)}
				/>

        {/* SUBMIT */}
        <Button variant="contained" onClick={validate}>
          {isLoading ? "loading..." : "submit"}
        </Button>
      </Stack>

      {/* ERROR ALERT */}
      <Snackbar open={openErr} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>
          {err}
        </Alert>
      </Snackbar>
    </div>
  )
}