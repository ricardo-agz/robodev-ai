import React from 'react';
import '../../App.css';
import axios from 'axios';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Button, CircularProgress } from '@mui/material';
import useApi from '../../hooks/useApi';
import authHeader from '../../services/auth-header';
import configData from '../../config.json'


export default function MonthlyPledgeShow(props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { result: monthlyPledge, loading, error, refresh } = useApi(`${configData.SERVER_URL}/monthlypledges/${id}`);

  /*
   * Delete monthlypledge
   */
  function handleDelete() {
    axios.delete(`${configData.SERVER_URL}/monthlypledges/${id}`, { headers: authHeader() });
    axios.delete(`${configData.SERVER_URL}/monthlypledges/${id}`, { headers: authHeader() });
    navigate('/monthlypledges');
  }


  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !monthlyPledge) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <div className='row'>
          <h1 className='paddedRight'>MonthlyPledge {id}</h1>

          {/* EDIT */}
          <Button variant="outlined" style={{marginRight: 15}}
            onClick={() => navigate(`/monthlypledges/${id}/edit`)}>edit
          </Button>

          {/* DELETE */}
          <Button variant="contained" color="error" 
            onClick={handleDelete}>delete
          </Button>
        </div>

        <label>Payment Amount: {monthlyPledge.payment_amount}</label>
        <label>Active: {monthlyPledge.active}</label>
        <label>User: {monthlyPledge.user}</label>

        {/* Monthly Pledge Workoutplans */}
        <div className='displayContainer'>
					<h3>Workoutplans</h3>
					<Button 
            variant='contained' 
            onClick={() => navigate(`/monthlypledges/${id}/workoutplans/new`)}
          >New Workoutplan</Button>

					<ul>
          {monthlyPledge.workoutplans && monthlyPledge.workoutplans.map((workoutplan, i) => (
            <div className="listItem" key={i}>
              <li>{workoutplan._id}</li>
              <Link to={`/workoutplans/${workoutplan._id}`}>
                <button className="listButton">show</button>
              </Link>
            </div>
          ))}
          </ul> 
				</div>

        
      </div>
    );
  }
}
