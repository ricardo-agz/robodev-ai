import React, { useState, useEffect } from 'react';
import '../../App.css';
import { useParams, useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';
import useApi from '../../hooks/useApi';
import authHeader from '../../services/auth-header';
import { CircularProgress } from '@mui/material';
import configData from '../../config.json'

export default function WorkoutPlanEdit() {
	const { id } = useParams();
  const navigate = useNavigate();
  const { result: workoutPlan, loading: workoutPlanLoading, error: fetchError, refresh } = useApi(`${configData.SERVER_URL}/workoutplans/${id}`);
  const [editLoading, setEditLoading] = useState(false);
  const [editError, setEditError] = useState(null);

	const handleSubmit = (target_days, curr_days_met, weekly_plan, monthlypledge) => {
    setEditLoading(true);
    setEditError(null);
    axios.put(`${configData.SERVER_URL}/workoutplans/${id}/edit`, 
    {
      target_days: target_days,
      curr_days_met: curr_days_met,
      weekly_plan: weekly_plan,
      monthlypledge: monthlypledge
    }, { headers: authHeader() })
    .then(_res => {
      navigate(`/workoutplans/${id}`)
    })
    .catch(err => {
      setEditError(err.response.data.message);
    })
    .then(_res => {
      setEditLoading(false);
    })
	};

	if (fetchError) {
		return <p style={{color: "red"}}>Error: {fetchError}</p>;
  } else if (workoutPlanLoading || !workoutPlan) {
		return <CircularProgress />;
	} else {
		return (
			<div className='container'>
				<h1>Edit Workout Plan</h1>

        {/* ERROR DISPLAY */}
        { editError &&
          <p style={{color: "red"}}>{editError}</p>
        }

        {/* FORM DISPLAY */}
				<ValidatedForm
					model={workoutPlan}
					loading={editLoading}
					submit={(target_days, curr_days_met, weekly_plan, monthlypledge) =>
						handleSubmit(target_days, curr_days_met, weekly_plan, monthlypledge)
					}
				/>
			</div>
		)
	}
}
