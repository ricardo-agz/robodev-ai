import React, { useState } from 'react';
import '../../App.css';
import { useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';
import authHeader from '../../services/auth-header';
import configData from '../../config.json'

export default function WorkoutPlanNew() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

	const handleSubmit = (target_days, curr_days_met, weekly_plan, monthlypledge) => {
    setLoading(true);
    setError(null);
		axios.post(`${configData.SERVER_URL}/workoutplans`, {
      target_days: target_days,
      curr_days_met: curr_days_met,
      weekly_plan: weekly_plan,
      monthlypledge: monthlypledge
    }, { headers: authHeader() })
    .then(_res => {
      navigate("/workoutplans")
    })
    .catch(err => {
      setError(err.response.data.message);
    })
    .then(_res => {
      setLoading(false);
    })
	};

	return (
		<div className='container'>
			<h1>Edit Workout Plan</h1>

      {/* ERROR DISPLAY */}
      { error &&
        <p style={{color: "red"}}>{error}</p>
      }

      {/* FORM DISPLAY */}
			<ValidatedForm
				loading={loading}
				submit={(target_days, curr_days_met, weekly_plan, monthlypledge) =>
					handleSubmit(target_days, curr_days_met, weekly_plan, monthlypledge)
				}
			/>
		</div>
	)
}
