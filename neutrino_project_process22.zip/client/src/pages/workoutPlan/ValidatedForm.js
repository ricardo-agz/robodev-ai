import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom';
import MuiAlert from '@mui/material/Alert';
import {
  Snackbar,
  TextField,
  Button,
  Checkbox,
  Stack
} from '@mui/material'

const Alert = React.forwardRef((props, ref) => {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

export default function ValidatedForm(props) {
  const { id } = useParams();
	const [target_days, setTargetDays] = useState(0);
	const [curr_days_met, setCurrDaysMet] = useState(0);
	const [weekly_plan, setWeeklyPlan] = useState('');
	const [monthlypledge, setMonthlypledge] = useState(id ? id : '');
  const [err, setErr] = useState(null);                       // error message  
  const [openErr, setOpenErr] = useState(false);              // is error display open
  const [isLoading, setIsLoading] = useState(props.loading);  // awaiting result

  /* 
   * Update loading state when props changes 
   */
  useEffect(() => {
    setIsLoading(props.loading);
  }, [props.loading])

  /* 
   * Load default values if model passed and model is updated 
   */
  useEffect(() => {
		if (props.model) {
      setTargetDays(props.model.target_days);
      setCurrDaysMet(props.model.curr_days_met);
      setWeeklyPlan(props.model.weekly_plan);
      setMonthlypledge(props.model.monthlypledge);
		}
	}, [props.model]);

  /*
   * Ensure all required fields are not empty
   */
  const validate = () => {
		if (target_days !== '' && curr_days_met !== '' && weekly_plan !== '' && monthlypledge !== '') {
			props.submit(target_days, curr_days_met, weekly_plan, monthlypledge)
		} else {
			if (target_days === '') {
				setErr('target_days cannot be left blank')
			}
			else if (curr_days_met === '') {
				setErr('curr_days_met cannot be left blank')
			}
			else if (weekly_plan === '') {
				setErr('weekly_plan cannot be left blank')
			}
			else if (monthlypledge === '') {
				setErr('monthlypledge cannot be left blank')
			}
      setOpenErr(true)
    }
  }

  /* 
   * Close error snackbar
   */
  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenErr(false);
  };

  return (
    <div className='container'>
      <Stack spacing={3}>
				<TextField
					label='target_days' size='small' type='Number'
					value={target_days}
					onChange={(e) => setTargetDays(e.target.value)}
				/>
				<TextField
					label='curr_days_met' size='small' type='Number'
					value={curr_days_met}
					onChange={(e) => setCurrDaysMet(e.target.value)}
				/>
				<TextField
					label='weekly_plan' size='small' type='String'
					value={weekly_plan}
					onChange={(e) => setWeeklyPlan(e.target.value)}
				/>
				<TextField
					label='monthlypledge' size='small' type='String'
					value={monthlypledge}
					onChange={(e) => setMonthlypledge(e.target.value)}
				/>

        {/* SUBMIT */}
        <Button variant="contained" onClick={validate}>
          {isLoading ? "loading..." : "submit"}
        </Button>
      </Stack>

      {/* ERROR ALERT */}
      <Snackbar open={openErr} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>
          {err}
        </Alert>
      </Snackbar>
    </div>
  )
}