import React from 'react';
import '../../App.css';
import axios from 'axios';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Button, CircularProgress } from '@mui/material';
import useApi from '../../hooks/useApi';
import authHeader from '../../services/auth-header';
import configData from '../../config.json'


export default function WorkoutPlanShow(props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { result: workoutPlan, loading, error, refresh } = useApi(`${configData.SERVER_URL}/workoutplans/${id}`);

  /*
   * Delete workoutplan
   */
  function handleDelete() {
    axios.delete(`${configData.SERVER_URL}/workoutplans/${id}`, { headers: authHeader() });
    axios.delete(`${configData.SERVER_URL}/workoutplans/${id}`, { headers: authHeader() });
    navigate('/workoutplans');
  }


  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !workoutPlan) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <div className='row'>
          <h1 className='paddedRight'>WorkoutPlan {id}</h1>

          {/* EDIT */}
          <Button variant="outlined" style={{marginRight: 15}}
            onClick={() => navigate(`/workoutplans/${id}/edit`)}>edit
          </Button>

          {/* DELETE */}
          <Button variant="contained" color="error" 
            onClick={handleDelete}>delete
          </Button>
        </div>

        <label>Target Days: {workoutPlan.target_days}</label>
        <label>Curr Days Met: {workoutPlan.curr_days_met}</label>
        <label>Weekly Plan: {workoutPlan.weekly_plan}</label>
        <label>Monthlypledge: {workoutPlan.monthlypledge}</label>

        
      </div>
    );
  }
}
