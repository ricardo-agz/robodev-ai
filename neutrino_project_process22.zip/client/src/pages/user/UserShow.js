import React, { useState } from 'react';
import '../../App.css';
import axios from 'axios';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Button, CircularProgress, ButtonGroup, TextField } from '@mui/material';
import useApi from '../../hooks/useApi';
import authHeader from '../../services/auth-header';
import configData from '../../config.json'


export default function UserShow(props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { result: user, loading, error, refresh } = useApi(`${configData.SERVER_URL}/users/${id}`);
	const [workoutGroupId, setWorkoutGroupId] = useState();
	const [friendId, setFriendId] = useState();

  /*
   * Delete user
   */
  function handleDelete() {
    axios.delete(`${configData.SERVER_URL}/users/${id}`, { headers: authHeader() });
    axios.delete(`${configData.SERVER_URL}/users/${id}`, { headers: authHeader() });
    navigate('/users');
  }


  /*
   * Add workoutgroup to user's workoutgroups list
   */ 
  function addWorkoutGroup() {
    try {
      axios.post(`${configData.SERVER_URL}/users/${id}/add-workoutgroup/${workoutGroupId}`,
				{}, { headers: authHeader() });
    } catch (e) {
      console.log(e);
    };
    window.location.reload();
  };

  /*
   * Drop workoutgroup from user's workoutgroups list
   */ 
  function dropWorkoutGroup(droppedId) {
    try {
      axios.post(`${configData.SERVER_URL}/users/${id}/drop-workoutgroup/${droppedId}`,
				{}, { headers: authHeader() });
    } catch (e) {
      console.log(e);
    };
    window.location.reload();
  };

  /*
   * Add friend to user's friends list
   */ 
  function addFriend() {
    try {
      axios.post(`${configData.SERVER_URL}/users/${id}/add-friend/${friendId}`,
				{}, { headers: authHeader() });
    } catch (e) {
      console.log(e);
    };
    window.location.reload();
  };

  /*
   * Drop friend from user's friends list
   */ 
  function dropFriend(droppedId) {
    try {
      axios.post(`${configData.SERVER_URL}/users/${id}/drop-friend/${droppedId}`,
				{}, { headers: authHeader() });
    } catch (e) {
      console.log(e);
    };
    window.location.reload();
  };

  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !user) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <div className='row'>
          <h1 className='paddedRight'>User {id}</h1>

          {/* EDIT */}
          <Button variant="outlined" style={{marginRight: 15}}
            onClick={() => navigate(`/users/${id}/edit`)}>edit
          </Button>

          {/* DELETE */}
          <Button variant="contained" color="error" 
            onClick={handleDelete}>delete
          </Button>
        </div>

        <label>Name: {user.name}</label>
        <label>Charity: {user.charity}</label>
        <label>Username: {user.username}</label>
        <label>Email: {user.email}</label>
        <label>Password: {user.password}</label>

        {/* User Payment Methods */}
        <div className='displayContainer'>
					<h3>Payment Methods</h3>
					<Button 
            variant='contained' 
            onClick={() => navigate(`/users/${id}/paymentmethods/new`)}
          >New Payment Method</Button>

					<ul>
          {user.paymentMethods && user.paymentMethods.map((paymentMethod, i) => (
            <div className="listItem" key={i}>
              <li>{paymentMethod._id}</li>
              <Link to={`/paymentmethods/${paymentMethod._id}`}>
                <button className="listButton">show</button>
              </Link>
            </div>
          ))}
          </ul> 
				</div>

        {/* User Monthly Pledges */}
        <div className='displayContainer'>
					<h3>Monthly Pledges</h3>
					<Button 
            variant='contained' 
            onClick={() => navigate(`/users/${id}/monthlypledges/new`)}
          >New Monthly Pledge</Button>

					<ul>
          {user.monthlyPledges && user.monthlyPledges.map((monthlyPledge, i) => (
            <div className="listItem" key={i}>
              <li>{monthlyPledge._id}</li>
              <Link to={`/monthlypledges/${monthlyPledge._id}`}>
                <button className="listButton">show</button>
              </Link>
            </div>
          ))}
          </ul> 
				</div>

        
        {/* Workout Groups*/}
        <div className='displayContainer'>
					<h3>Workout Groups</h3>

					<div className='row'>
						<TextField
							label='course id' size='small' style={{marginRight: 10}}
							onChange={(e) => { setWorkoutGroupId(e.target.value) }}
						/>
						<Button 
              variant='contained' 
              onClick={addWorkoutGroup}
            >
              Add Workout Group
            </Button>
					</div>

					<ul>
          {user.workoutGroups && user.workoutGroups.map((workoutGroup, i) => (
						<div className='listItem' key={i}>
							<li>{workoutGroup._id}</li>
							<ButtonGroup variant='outlined' size='small'>
								<Button onClick={() => navigate(`/workoutgroups/${workoutGroup}._id`)}>show</Button>
                <Button color='error' onClick={() => dropWorkoutGroup(workoutGroup._id)}>drop</Button>
							</ButtonGroup>
						</div>
					))}
					</ul>
				</div>

        {/* Friends*/}
        <div className='displayContainer'>
					<h3>Friends</h3>

					<div className='row'>
						<TextField
							label='course id' size='small' style={{marginRight: 10}}
							onChange={(e) => { setFriendId(e.target.value) }}
						/>
						<Button 
              variant='contained' 
              onClick={addFriend}
            >
              Add Friend
            </Button>
					</div>

					<ul>
          {user.friends && user.friends.map((friend, i) => (
						<div className='listItem' key={i}>
							<li>{friend._id}</li>
							<ButtonGroup variant='outlined' size='small'>
								<Button onClick={() => navigate(`/users/${friend}._id`)}>show</Button>
                <Button color='error' onClick={() => dropFriend(friend._id)}>drop</Button>
							</ButtonGroup>
						</div>
					))}
					</ul>
				</div>

      </div>
    );
  }
}
