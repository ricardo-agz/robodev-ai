import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom';
import MuiAlert from '@mui/material/Alert';
import {
  Snackbar,
  TextField,
  Button,
  Checkbox,
  Stack
} from '@mui/material'

const Alert = React.forwardRef((props, ref) => {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

export default function ValidatedForm(props) {
  
	const [name, setName] = useState('');
	const [charity, setCharity] = useState('');
	const [username, setUsername] = useState('');
	const [email, setEmail] = useState('');
	const [password, setPassword] = useState('');
  const [err, setErr] = useState(null);                       // error message  
  const [openErr, setOpenErr] = useState(false);              // is error display open
  const [isLoading, setIsLoading] = useState(props.loading);  // awaiting result

  /* 
   * Update loading state when props changes 
   */
  useEffect(() => {
    setIsLoading(props.loading);
  }, [props.loading])

  /* 
   * Load default values if model passed and model is updated 
   */
  useEffect(() => {
		if (props.model) {
      setName(props.model.name);
      setCharity(props.model.charity);
      setUsername(props.model.username);
      setEmail(props.model.email);
      setPassword(props.model.password);
		}
	}, [props.model]);

  /*
   * Ensure all required fields are not empty
   */
  const validate = () => {
		if (name !== '' && charity !== '' && username !== '' && email !== '' && password !== '') {
			props.submit(name, charity, username, email, password)
		} else {
			if (name === '') {
				setErr('name cannot be left blank')
			}
			else if (charity === '') {
				setErr('charity cannot be left blank')
			}
			else if (username === '') {
				setErr('username cannot be left blank')
			}
			else if (email === '') {
				setErr('email cannot be left blank')
			}
			else if (password === '') {
				setErr('password cannot be left blank')
			}
      setOpenErr(true)
    }
  }

  /* 
   * Close error snackbar
   */
  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenErr(false);
  };

  return (
    <div className='container'>
      <Stack spacing={3}>
				<TextField
					label='name' size='small' type='String'
					value={name}
					onChange={(e) => setName(e.target.value)}
				/>
				<TextField
					label='charity' size='small' type='String'
					value={charity}
					onChange={(e) => setCharity(e.target.value)}
				/>
				<TextField
					label='username' size='small' type='String'
					value={username}
					onChange={(e) => setUsername(e.target.value)}
				/>
				<TextField
					label='email' size='small' type='String'
					value={email}
					onChange={(e) => setEmail(e.target.value)}
				/>
				<TextField
					label='password' size='small' type='password'
					value={password}
					onChange={(e) => setPassword(e.target.value)}
				/>

        {/* SUBMIT */}
        <Button variant="contained" onClick={validate}>
          {isLoading ? "loading..." : "submit"}
        </Button>
      </Stack>

      {/* ERROR ALERT */}
      <Snackbar open={openErr} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>
          {err}
        </Alert>
      </Snackbar>
    </div>
  )
}