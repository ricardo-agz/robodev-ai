import React, { useState } from 'react';
import '../../App.css';
import { useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';
import authHeader from '../../services/auth-header';
import configData from '../../config.json'

export default function UserNew() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

	const handleSubmit = (name, charity, username, email, password) => {
    setLoading(true);
    setError(null);
		axios.post(`${configData.SERVER_URL}/users`, {
      name: name,
      charity: charity,
      username: username,
      email: email,
      password: password
    }, { headers: authHeader() })
    .then(_res => {
      navigate("/login")
    })
    .catch(err => {
      setError(err.response.data.message);
    })
    .then(_res => {
      setLoading(false);
    })
	};

	return (
		<div className='container'>
			<h1>Edit User</h1>

      {/* ERROR DISPLAY */}
      { error &&
        <p style={{color: "red"}}>{error}</p>
      }

      {/* FORM DISPLAY */}
			<ValidatedForm
				loading={loading}
				submit={(name, charity, username, email, password) =>
					handleSubmit(name, charity, username, email, password)
				}
			/>
		</div>
	)
}
