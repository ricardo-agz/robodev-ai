import React from "react";
import './App.css';
import { Routes, Route } from "react-router-dom";
import Home from './Home';
import { Users, UserShow, UserNew, UserEdit } from './pages/user/index';
import { PaymentMethods, PaymentMethodShow, PaymentMethodNew, PaymentMethodEdit } from './pages/paymentMethod/index';
import { MonthlyPledges, MonthlyPledgeShow, MonthlyPledgeNew, MonthlyPledgeEdit } from './pages/monthlyPledge/index';
import { WorkoutPlans, WorkoutPlanShow, WorkoutPlanNew, WorkoutPlanEdit } from './pages/workoutPlan/index';
import { WorkoutGroups, WorkoutGroupShow, WorkoutGroupNew, WorkoutGroupEdit } from './pages/workoutGroup/index';
import { UserContext } from './hooks/UserContext';
import useFindUser from './hooks/useFindUser';
import PrivateRoute from './auth/PrivateRoute';
import Login from './auth/Login';
import Nav from './components/Nav'


function App() {
	const { user, setUser, loading } = useFindUser();

  return (
		<UserContext.Provider value={{ authUser: user, setAuthUser: setUser, authLoading: loading }}>
    <div className="App">
			<Nav/>
      <Routes>
        <Route path="/" element={<Home />} />

				{/* AUTH */}
				<Route path='/login' element={<Login />} />
				<Route path='/register' element={<UserNew />} />

				{/* User */}
				<Route
					path='/users'
					element={ <PrivateRoute component={<Users />} />}
				/>
				<Route
					path='/users/:id'
					element={ <PrivateRoute component={<UserShow />} />}
				/>
				<Route path='/users/new' element={<UserNew />} />
				<Route
					path='/users/:id/edit'
					element={ <PrivateRoute component={<UserEdit />} />}
				/>
<Route path='/users/:id/paymentmethods/new' element=<PaymentMethodNew /> /><Route path='/users/:id/monthlypledges/new' element=<MonthlyPledgeNew /> />
				{/* PaymentMethod */}
				<Route path='/paymentmethods' element={<PaymentMethods />} />
				<Route path='/paymentmethods/:id' element={<PaymentMethodShow />} />
				<Route path='/paymentmethods/new' element={<PaymentMethodNew />} />
				<Route path='/paymentmethods/:id/edit' element={<PaymentMethodEdit />} />

				{/* MonthlyPledge */}
				<Route path='/monthlypledges' element={<MonthlyPledges />} />
				<Route path='/monthlypledges/:id' element={<MonthlyPledgeShow />} />
				<Route path='/monthlypledges/new' element={<MonthlyPledgeNew />} />
				<Route path='/monthlypledges/:id/edit' element={<MonthlyPledgeEdit />} />
<Route path='/monthlypledges/:id/workoutplans/new' element=<WorkoutPlanNew /> />
				{/* WorkoutPlan */}
				<Route path='/workoutplans' element={<WorkoutPlans />} />
				<Route path='/workoutplans/:id' element={<WorkoutPlanShow />} />
				<Route path='/workoutplans/new' element={<WorkoutPlanNew />} />
				<Route path='/workoutplans/:id/edit' element={<WorkoutPlanEdit />} />

				{/* WorkoutGroup */}
				<Route path='/workoutgroups' element={<WorkoutGroups />} />
				<Route path='/workoutgroups/:id' element={<WorkoutGroupShow />} />
				<Route path='/workoutgroups/new' element={<WorkoutGroupNew />} />
				<Route path='/workoutgroups/:id/edit' element={<WorkoutGroupEdit />} />
      </Routes>  
    </div>
		</UserContext.Provider>
  );
}

export default App;
