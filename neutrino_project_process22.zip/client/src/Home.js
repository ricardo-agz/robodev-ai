import React from 'react';
import './App.css';

export default function Home() {

	return (
		<div className='App'>
			<h1>Welcome to Neutrino!</h1>
    </div>
  )
}