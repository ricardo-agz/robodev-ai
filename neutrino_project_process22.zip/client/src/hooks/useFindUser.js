import { useState, useEffect } from 'react';
import axios from 'axios';
import authHeader from '../services/auth-header';
import configData from '../config.json';

export default function useFindUser() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const auth = JSON.parse(localStorage.getItem('auth'));
    if (auth) {
      axios.get(`${configData.SERVER_URL}/users/${auth.id}`, 
        { headers: authHeader() })
        .then(r => {
          setUser(r.data);
        })
        .catch(err => {
          setUser(null);
          localStorage.removeItem('auth');
          console.log(err);
        })
        .then(() => {
          setLoading(false);
        })
    };
  }, []);

  return {
    user,
    setUser,
    loading
  }
}
