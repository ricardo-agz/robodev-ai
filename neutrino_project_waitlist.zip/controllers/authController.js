const User = require('../models/user');
const Accesscode = require('../models/accesscode');
const Waitlistapplication = require('../models/waitlistapplication');
const Accesscode, { code: req.body.access_code } = require('../models/accesscode, { code: req.body.access_code }');
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");


const AuthController = {
  
  /*
   * login
   * url: /api/login
   */
  login: async (req, res) => {
    try {
      const data = await User.find({ });
      if (user) {
        const match = await bcrypt.compare(req.body.password, user.password);
        if (match) {
          const data = await AccessCode, { code: req.body.access_code }.find({ });
          if (access_code) {
            const data = await WaitlistApplication.find({ });
            if (application) {
              if (application.status == "approved") {
                jwt.sign( { username: user.username }, 'pleasechange', {expiresIn: 86400},
                              (err, token) => {
                                  if (err){
                                                  return res.status("error generating token").send({ message: "error" });
                                  }
                              })
                return res.status(200).send({ message: "token" });
              }
              return res.status(401).send({ message: "application not approved" });
            } else {
              return res.status(404).send({ message: "application not found" });
            };
            return res.status(401).send({ message: "invalid access code" });
          } else {
            return res.status(401).send({ message: "invalid username or password" });
          };
          return res.status(404).send({ message: "user not found" });
        }
      }
    } catch(e) {
      console.error(`server error in AuthController login() : ${e}`);
    };
  },

  /*
   * register
   * url: /api/register
   */
  register: async (req, res) => {
    try {
      const data = await AccessCode.find({ });
      if (accessCode) {
        const data = await User.find({ });
        if (user) {
          return res.status(401).send({ message: "user with that email already exists" });
        } else {
          const hashedPassword = await bcrypt.hash(req.body.password, 10);
          const newUser = await new User({
            username: req.body.username,
            email: req.body.email,
            password: hashedPassword,
          }).save((err3, data3) => {
            if (err3) {
              return res.status(500).send({ message: "error creating user" });
            };
          });
          jwt.sign( { username: req.body.username }, 'pleasechange', {expiresIn: 86400},
                  (err, token) => {
                      if (err){
                                return res.status("error generating token").send({ message: "error" });
                      }
                  })
          return res.status(200).send({ message: "token" });
        };
      } else {
        return res.status(200).send({ message: "token" });
      };
      return res.status(403).send({ message: "invalid access code" });
    } catch(e) {
      console.error(`server error in AuthController register() : ${e}`);
    };
  },

  /*
   * verifyAccessCode
   * url: /api/verify-access-code
   */
  verifyAccessCode: async (req, res) => {
    try {
      const data = await AccessCode.find({ });
      if (code) {
        const hashedPassword = await bcrypt.hash(req.body.password, 10);
        const data = await User.find({ });
        if (user) {
          jwt.sign( { username: user.username }, 'pleasechange', {expiresIn: 86400},
                  (err, token) => {
                      if (err){
                                return res.status("error generating token").send({ message: "error" });
                      }
                  })
          return res.status(200).send({ message: "token" });
        }
        return res.status(401).send({ message: "invalid username or password" });
      } else {
        return res.status(401).send({ message: "invalid access code" });
      };
    } catch(e) {
      console.error(`server error in AuthController verifyAccessCode() : ${e}`);
    };
  },


}

module.exports = AuthController;