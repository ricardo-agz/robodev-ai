const Jwttoken = require('../models/jwttoken');


const JWTTokenController = {
  
  /*
   * index
   * url: /api/jwttokens
   */
  index: async (req, res) => {
    try {
      const data = await jwttoken.find({});
      return res.status(200).send(data);
    } catch(e) {
      console.error(`server error in JWTTokenController index() : ${e}`);
    };
  },

  /*
   * show
   * url: /api/jwttokens/:id
   * params: ['id']
	 */
  show: async (req, res) => {
    try {
      const { id } = req.params;
      const data = await jwttoken.findById(id);
      return res.status(200).send(data);
    } catch(e) {
      console.error(`server error in JWTTokenController show() : ${e}`);
    };
  },

  /*
   * update
   * url: /api/jwttokens/:id
   * params: ['id']
	 */
  update: async (req, res) => {
    try {
      const { id } = req.params;
      const newData = await jwttoken.findByIdAndUpdate(id,
      {
        token,
      },
      (err, data) => {
        if (err) {
          return res.status(500).send({ message: "Error updating jwttoken" });
        };
        return res.status(200).send({ message: "jwttoken was successfully updated!" });
      });
    } catch(e) {
      console.error(`server error in JWTTokenController update() : ${e}`);
    };
  },

  /*
   * delete
   * url: /api/jwttokens/:id
   * params: ['id']
	 */
  delete: async (req, res) => {
    try {
      const { id } = req.params;
      const data = await jwttoken.findByIdAndDelete(id,
      (err, data) => {
        if (err) {
          return res.status(500).send({ message: "Error deleting jwttoken" });
        };
        return res.status(200).send({ message: "jwttoken was successfully deleted" });
      });
    } catch(e) {
      console.error(`server error in JWTTokenController delete() : ${e}`);
    };
  },


}

module.exports = JWTTokenController;