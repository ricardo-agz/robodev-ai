const mongoose = require('mongoose');

const JWTTokenSchema = new mongoose.Schema({
	token: {
		type: String,
		required: true
	},
});


const JWTToken = mongoose.model('JWTToken', JWTTokenSchema);
module.exports = JWTToken;
