const mongoose = require('mongoose');

const WaitlistApplicationSchema = new mongoose.Schema({
	status: {
		type: String,
		required: true
	},
	applicants: [
		{
			type: mongoose.Schema.Types.ObjectId,
			ref: 'User'
		}
	],
});


const WaitlistApplication = mongoose.model('WaitlistApplication', WaitlistApplicationSchema);
module.exports = WaitlistApplication;
