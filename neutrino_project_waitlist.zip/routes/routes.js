const express       = require('express');
const router        = express.Router();
module.exports      = router;

const AuthController = require('../controllers/AuthController');
const AccessCodeController = require('../controllers/AccessCodeController');
const UserController = require('../controllers/UserController');
const JWTTokenController = require('../controllers/JWTTokenController');

// Home
router.get('/', (_req, res) => {
  res.status(200).send({ message: 'Welcome to Neutrino!' });
});

router.post('/api/login', AuthController.login);
router.post('/api/register', AuthController.register);
router.post('/api/verify-access-code', AuthController.verifyAccessCode);

router.get('/api/accesscodes', AccessCodeController.index);
router.get('/api/accesscodes/:id', AccessCodeController.show);
router.post('/api/accesscodes', AccessCodeController.create);
router.put('/api/accesscodes/:id', AccessCodeController.update);
router.delete('/api/accesscodes/:id', AccessCodeController.delete);

router.get('/api/users', UserController.index);
router.get('/api/users/:id', UserController.show);
router.put('/api/users/:id', UserController.update);
router.delete('/api/users/:id', UserController.delete);

router.get('/api/jwttokens', JWTTokenController.index);
router.get('/api/jwttokens/:id', JWTTokenController.show);
router.put('/api/jwttokens/:id', JWTTokenController.update);
router.delete('/api/jwttokens/:id', JWTTokenController.delete);


// Default response for any other request
router.use((_req, res) => {
  res.status(404).send({ message: "404 not found" });
});