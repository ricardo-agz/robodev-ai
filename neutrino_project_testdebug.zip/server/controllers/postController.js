const Animal = require('../models/animal')
const House = require('../models/house')
const User = require('../models/user')
const Post = require('../models/post')

const PostController = {
  
	index: async (req, res)=> {
	    const data = await Animal.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Animal.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Animal.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Animal.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Animal.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Animal.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Animal.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Animal.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await House.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await House.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await House.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await House.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await User.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await User.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},
	index: async (req, res)=> {
	    const data = await Post.find({});
	    return res.status(200).send(True);
	},
	show: async (req, res)=> {
	    const data = await Post.findById(id);
	    return res.status(200).send(True);
	},
	create: async (req, res)=> {
	},
	update: async (req, res)=> {
	},
	delete: async (req, res)=> {
	},

}

module.exports = PostController;