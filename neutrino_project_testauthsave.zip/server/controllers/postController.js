const Post = require('../models/post');

const PostController = {
  
	/*
	 * index
	 * url: /posts
	 */
	index: async (req, res) => {
		try {
	 const data = await Post.find({});
	 return res.status(200).send(data);
		} catch(e) {
			res.status(500).send({ message: `server error in PostController index() : ${e}` });
		};
	},

	/*
	 * show
	 * url: /posts/:id
	 * params: ['id']
	 */
	show: async (req, res) => {
		try {
			const { id } = req.params;
	 const data = await Post.findById(id);
	 return res.status(200).send(data);
		} catch(e) {
			res.status(500).send({ message: `server error in PostController show() : ${e}` });
		};
	},

	/*
	 * create
	 * url: /posts
	 */
	create: async (req, res) => {
		try {
	 const newData = await new Post({
	  title,
	  content,
	 }).save((err, data) => {
	  if (err) {
	   return res.status(500).send({ message: "Error creating new Post" });
	  };
	  return res.status(200).send({ message: "New Post was successfully created!" });
	 });
		} catch(e) {
			res.status(500).send({ message: `server error in PostController create() : ${e}` });
		};
	},

	/*
	 * update
	 * url: /posts/:id
	 * params: ['id']
	 */
	update: async (req, res) => {
		try {
			const { id } = req.params;
	 const newData = await Post.updateOne(id,
	 {
	  title,
	  content,
	 },
	 (err, data) => {
	  if (err) {
	   return res.status(500).send({ message: "Error updating Post" });
	  };
	  return res.status(200).send({ message: "Post was successfully updated!" });
	 });
		} catch(e) {
			res.status(500).send({ message: `server error in PostController update() : ${e}` });
		};
	},

	/*
	 * delete
	 * url: /posts/:id
	 * params: ['id']
	 */
	delete: async (req, res) => {
		try {
			const { id } = req.params;
	 const data = await Post.deleteOne(id,
	 (err, data) => {
	  if (err) {
	   return res.status(500).send({ message: "Error deleting Post" });
	  };
	  return res.status(200).send({ message: "Post was successfully deleted" });
	 });
		} catch(e) {
			res.status(500).send({ message: `server error in PostController delete() : ${e}` });
		};
	},


}

module.exports = PostController;