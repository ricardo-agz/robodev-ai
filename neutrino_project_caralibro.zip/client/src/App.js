import React from "react";
import './App.css';
import { Routes, Route } from "react-router-dom";
import Home from './Home';
import { Users, UserShow, UserNew, UserEdit } from './pages/user/index';
import { Posts, PostShow, PostNew, PostEdit } from './pages/post/index';
import { Comments, CommentShow, CommentNew, CommentEdit } from './pages/comment/index';
import { Likes, LikeShow, LikeNew, LikeEdit } from './pages/like/index';
import { Shares, ShareShow, ShareNew, ShareEdit } from './pages/share/index';
import { Storys, StoryShow, StoryNew, StoryEdit } from './pages/story/index';


function App() {
  return (
    <div className="App">
			<Nav/>
      <Routes>
        <Route path="/" element={<Home />} />

				{/* User */}
				<Route path='/users' element={<Users />} />
				<Route path='/users/:id' element={<UserShow />} />
				<Route path='/users/new' element={<UserNew />} />
				<Route path='/users/:id/edit' element={<UserEdit />} />

				{/* Post */}
				<Route path='/posts' element={<Posts />} />
				<Route path='/posts/:id' element={<PostShow />} />
				<Route path='/posts/new' element={<PostNew />} />
				<Route path='/posts/:id/edit' element={<PostEdit />} />

				{/* Comment */}
				<Route path='/comments' element={<Comments />} />
				<Route path='/comments/:id' element={<CommentShow />} />
				<Route path='/comments/new' element={<CommentNew />} />
				<Route path='/comments/:id/edit' element={<CommentEdit />} />

				{/* Like */}
				<Route path='/likes' element={<Likes />} />
				<Route path='/likes/:id' element={<LikeShow />} />
				<Route path='/likes/new' element={<LikeNew />} />
				<Route path='/likes/:id/edit' element={<LikeEdit />} />

				{/* Share */}
				<Route path='/shares' element={<Shares />} />
				<Route path='/shares/:id' element={<ShareShow />} />
				<Route path='/shares/new' element={<ShareNew />} />
				<Route path='/shares/:id/edit' element={<ShareEdit />} />

				{/* Story */}
				<Route path='/storys' element={<Storys />} />
				<Route path='/storys/:id' element={<StoryShow />} />
				<Route path='/storys/new' element={<StoryNew />} />
				<Route path='/storys/:id/edit' element={<StoryEdit />} />
      </Routes>  
    </div>
  );
}

export default App;
