import React, { useState, useEffect } from 'react';
import '../../App.css';
import { useParams, useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';
import useApi from '../../hooks/useApi';

import { CircularProgress } from '@mui/material';
import configData from '../../config.json'

export default function CommentEdit() {
  const navigate = useNavigate();
  const [editLoading, setEditLoading] = useState(false);
  const [editError, setEditError] = useState(null);
  const { id } = useParams();
  const {
    result: comment,
    loading: commentLoading,
    error: fetchError,
    refresh
  } = useApi(`${configData.SERVER_URL}/comments/${id}`);

	const handleSubmit = (text) => {
    setEditLoading(true);
    setEditError(null);
    axios.put(`${configData.SERVER_URL}/comments/${id}/edit`, 
    {
      text: text
    })
    .then(_res => {
      navigate(`/comments/${id}`)
    })
    .catch(err => {
      setEditError(err.response.data.message);
    })
    .then(_res => {
      setEditLoading(false);
    })
	};

	if (fetchError) {
		return <p style={{color: "red"}}>Error: {fetchError}</p>;
  } else if (commentLoading || !comment) {
		return <CircularProgress />;
	} else {
		return (
			<div className='container'>
				<h1>Edit Comment</h1>

        {/* ERROR DISPLAY */}
        { editError &&
          <p style={{color: "red"}}>{editError}</p>
        }

        {/* FORM DISPLAY */}
				<ValidatedForm
					model={comment}
					loading={editLoading}
					submit={(text) =>
						handleSubmit(text)
					}
				/>
			</div>
		)
	}
}
