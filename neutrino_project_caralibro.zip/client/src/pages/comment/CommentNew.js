import React, { useState } from 'react';
import '../../App.css';
import { useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';

import configData from '../../config.json'

export default function CommentNew() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

	const handleSubmit = (text) => {
    setLoading(true);
    setError(null);
		axios.post(`${configData.SERVER_URL}/comments`, {
      text: text
    })
    .then(_res => {
      navigate("/comments")
    })
    .catch(err => {
      setError(err.response.data.message);
    })
    .then(_res => {
      setLoading(false);
    })
	};

	return (
		<div className='container'>
			<h1>Edit Comment</h1>

      {/* ERROR DISPLAY */}
      { error &&
        <p style={{color: "red"}}>{error}</p>
      }

      {/* FORM DISPLAY */}
			<ValidatedForm
				loading={loading}
				submit={(text) =>
					handleSubmit(text)
				}
			/>
		</div>
	)
}
