import React from 'react';
import '../../App.css';
import axios from 'axios';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Button, CircularProgress } from '@mui/material';
import useApi from '../../hooks/useApi';

import configData from '../../config.json'


export default function CommentShow(props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { result: comment, loading, error, refresh } = useApi(`${configData.SERVER_URL}/comments/${id}`);

  /*
   * Delete comment
   */
  function handleDelete() {
    axios.delete(`${configData.SERVER_URL}/comments/${id}`);
    axios.delete(`${configData.SERVER_URL}/comments/${id}`);
    navigate('/comments');
  }


  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !comment) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <div className='row'>
          <h1 className='paddedRight'>Comment {id}</h1>

          {/* EDIT */}
          <Button variant="outlined" style={{marginRight: 15}}
            onClick={() => navigate(`/comments/${id}/edit`)}>edit
          </Button>

          {/* DELETE */}
          <Button variant="contained" color="error" 
            onClick={handleDelete}>delete
          </Button>
        </div>

        <label>Text: {comment.text}</label>

        
      </div>
    );
  }
}
