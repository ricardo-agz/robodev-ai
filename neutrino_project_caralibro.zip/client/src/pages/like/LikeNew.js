import React, { useState } from 'react';
import '../../App.css';
import { useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';

import configData from '../../config.json'

export default function LikeNew() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

	const handleSubmit = (like_count) => {
    setLoading(true);
    setError(null);
		axios.post(`${configData.SERVER_URL}/likes`, {
      like_count: like_count
    })
    .then(_res => {
      navigate("/likes")
    })
    .catch(err => {
      setError(err.response.data.message);
    })
    .then(_res => {
      setLoading(false);
    })
	};

	return (
		<div className='container'>
			<h1>Edit Like</h1>

      {/* ERROR DISPLAY */}
      { error &&
        <p style={{color: "red"}}>{error}</p>
      }

      {/* FORM DISPLAY */}
			<ValidatedForm
				loading={loading}
				submit={(like_count) =>
					handleSubmit(like_count)
				}
			/>
		</div>
	)
}
