import React from 'react';
import '../../App.css';
import axios from 'axios';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Button, CircularProgress } from '@mui/material';
import useApi from '../../hooks/useApi';

import configData from '../../config.json'


export default function LikeShow(props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { result: like, loading, error, refresh } = useApi(`${configData.SERVER_URL}/likes/${id}`);

  /*
   * Delete like
   */
  function handleDelete() {
    axios.delete(`${configData.SERVER_URL}/likes/${id}`);
    axios.delete(`${configData.SERVER_URL}/likes/${id}`);
    navigate('/likes');
  }


  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !like) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <div className='row'>
          <h1 className='paddedRight'>Like {id}</h1>

          {/* EDIT */}
          <Button variant="outlined" style={{marginRight: 15}}
            onClick={() => navigate(`/likes/${id}/edit`)}>edit
          </Button>

          {/* DELETE */}
          <Button variant="contained" color="error" 
            onClick={handleDelete}>delete
          </Button>
        </div>

        <label>Like Count: {like.like_count}</label>

        
      </div>
    );
  }
}
