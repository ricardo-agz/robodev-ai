import React from 'react';
import '../../App.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Button, ButtonGroup, CircularProgress } from '@mui/material';
import useApi from '../../hooks/useApi';
import configData from '../../config.json'

export default function Likes() {
  const { result: likes, loading, error, refresh } = useApi(`${configData.SERVER_URL}/likes`);
  const navigate = useNavigate();

  function handleDelete(id) {
    axios.delete(`${configData.SERVER_URL}/likes/${id}`);
    window.location.reload();
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !likes) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <h1>Likes</h1>
        <Button 
          variant={"contained"}
          onClick={() => navigate("/likes/new")}
        >
        New Like
        </Button>

        <ul>
        {likes.map((like, i) => (
          <div className="listItem" key={i}>
            <li key={i}>{like.like_count}</li>
            <ButtonGroup variant="outlined" size="small">
              <Button onClick={() => navigate(`/likes/${like._id}`)}>show</Button>
              <Button onClick={() => navigate(`/likes/${like._id}/edit`)}>edit</Button>
              <Button color="error" onClick={() => handleDelete(like._id)}>delete</Button>
            </ButtonGroup>
          </div>
        ))}
        </ul>
      </div>
    );
  };
};
