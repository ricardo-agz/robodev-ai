import React, { useState, useEffect } from 'react';
import '../../App.css';
import { useParams, useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';
import useApi from '../../hooks/useApi';

import { CircularProgress } from '@mui/material';
import configData from '../../config.json'

export default function LikeEdit() {
  const navigate = useNavigate();
  const [editLoading, setEditLoading] = useState(false);
  const [editError, setEditError] = useState(null);
  const { id } = useParams();
  const {
    result: like,
    loading: likeLoading,
    error: fetchError,
    refresh
  } = useApi(`${configData.SERVER_URL}/likes/${id}`);

	const handleSubmit = (like_count) => {
    setEditLoading(true);
    setEditError(null);
    axios.put(`${configData.SERVER_URL}/likes/${id}/edit`, 
    {
      like_count: like_count
    })
    .then(_res => {
      navigate(`/likes/${id}`)
    })
    .catch(err => {
      setEditError(err.response.data.message);
    })
    .then(_res => {
      setEditLoading(false);
    })
	};

	if (fetchError) {
		return <p style={{color: "red"}}>Error: {fetchError}</p>;
  } else if (likeLoading || !like) {
		return <CircularProgress />;
	} else {
		return (
			<div className='container'>
				<h1>Edit Like</h1>

        {/* ERROR DISPLAY */}
        { editError &&
          <p style={{color: "red"}}>{editError}</p>
        }

        {/* FORM DISPLAY */}
				<ValidatedForm
					model={like}
					loading={editLoading}
					submit={(like_count) =>
						handleSubmit(like_count)
					}
				/>
			</div>
		)
	}
}
