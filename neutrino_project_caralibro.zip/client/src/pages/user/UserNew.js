import React, { useState } from 'react';
import '../../App.css';
import { useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';

import configData from '../../config.json'

export default function UserNew() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

	const handleSubmit = (beyonce) => {
    setLoading(true);
    setError(null);
		axios.post(`${configData.SERVER_URL}/users`, {
      beyonce: beyonce
    })
    .then(_res => {
      navigate("/users")
    })
    .catch(err => {
      setError(err.response.data.message);
    })
    .then(_res => {
      setLoading(false);
    })
	};

	return (
		<div className='container'>
			<h1>Edit User</h1>

      {/* ERROR DISPLAY */}
      { error &&
        <p style={{color: "red"}}>{error}</p>
      }

      {/* FORM DISPLAY */}
			<ValidatedForm
				loading={loading}
				submit={(beyonce) =>
					handleSubmit(beyonce)
				}
			/>
		</div>
	)
}
