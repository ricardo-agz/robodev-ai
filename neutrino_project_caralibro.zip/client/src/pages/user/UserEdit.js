import React, { useState, useEffect } from 'react';
import '../../App.css';
import { useParams, useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';
import useApi from '../../hooks/useApi';

import { CircularProgress } from '@mui/material';
import configData from '../../config.json'

export default function UserEdit() {
  const navigate = useNavigate();
  const [editLoading, setEditLoading] = useState(false);
  const [editError, setEditError] = useState(null);
  const { id } = useParams();
  const {
    result: user,
    loading: userLoading,
    error: fetchError,
    refresh
  } = useApi(`${configData.SERVER_URL}/users/${id}`);

	const handleSubmit = (beyonce) => {
    setEditLoading(true);
    setEditError(null);
    axios.put(`${configData.SERVER_URL}/users/${id}/edit`, 
    {
      beyonce: beyonce
    })
    .then(_res => {
      navigate(`/users/${id}`)
    })
    .catch(err => {
      setEditError(err.response.data.message);
    })
    .then(_res => {
      setEditLoading(false);
    })
	};

	if (fetchError) {
		return <p style={{color: "red"}}>Error: {fetchError}</p>;
  } else if (userLoading || !user) {
		return <CircularProgress />;
	} else {
		return (
			<div className='container'>
				<h1>Edit User</h1>

        {/* ERROR DISPLAY */}
        { editError &&
          <p style={{color: "red"}}>{editError}</p>
        }

        {/* FORM DISPLAY */}
				<ValidatedForm
					model={user}
					loading={editLoading}
					submit={(beyonce) =>
						handleSubmit(beyonce)
					}
				/>
			</div>
		)
	}
}
