import React from 'react';
import '../../App.css';
import axios from 'axios';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Button, CircularProgress } from '@mui/material';
import useApi from '../../hooks/useApi';

import configData from '../../config.json'


export default function UserShow(props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { result: user, loading, error, refresh } = useApi(`${configData.SERVER_URL}/users/${id}`);

  /*
   * Delete user
   */
  function handleDelete() {
    axios.delete(`${configData.SERVER_URL}/users/${id}`);
    axios.delete(`${configData.SERVER_URL}/users/${id}`);
    navigate('/users');
  }


  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !user) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <div className='row'>
          <h1 className='paddedRight'>User {id}</h1>

          {/* EDIT */}
          <Button variant="outlined" style={{marginRight: 15}}
            onClick={() => navigate(`/users/${id}/edit`)}>edit
          </Button>

          {/* DELETE */}
          <Button variant="contained" color="error" 
            onClick={handleDelete}>delete
          </Button>
        </div>

        <label>Beyonce: {user.beyonce}</label>

        
      </div>
    );
  }
}
