import React from 'react';
import '../../App.css';
import axios from 'axios';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Button, CircularProgress } from '@mui/material';
import useApi from '../../hooks/useApi';

import configData from '../../config.json'


export default function StoryShow(props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { result: story, loading, error, refresh } = useApi(`${configData.SERVER_URL}/storys/${id}`);

  /*
   * Delete story
   */
  function handleDelete() {
    axios.delete(`${configData.SERVER_URL}/storys/${id}`);
    axios.delete(`${configData.SERVER_URL}/storys/${id}`);
    navigate('/storys');
  }


  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !story) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <div className='row'>
          <h1 className='paddedRight'>Story {id}</h1>

          {/* EDIT */}
          <Button variant="outlined" style={{marginRight: 15}}
            onClick={() => navigate(`/storys/${id}/edit`)}>edit
          </Button>

          {/* DELETE */}
          <Button variant="contained" color="error" 
            onClick={handleDelete}>delete
          </Button>
        </div>

        <label>Content: {story.content}</label>
        <label>Content: {story.content}</label>

        
      </div>
    );
  }
}
