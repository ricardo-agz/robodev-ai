import React, { useState } from 'react';
import '../../App.css';
import { useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';

import configData from '../../config.json'

export default function ShareNew() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

	const handleSubmit = (share_number, shate_to) => {
    setLoading(true);
    setError(null);
		axios.post(`${configData.SERVER_URL}/shares`, {
      share_number: share_number,
      shate_to: shate_to
    })
    .then(_res => {
      navigate("/shares")
    })
    .catch(err => {
      setError(err.response.data.message);
    })
    .then(_res => {
      setLoading(false);
    })
	};

	return (
		<div className='container'>
			<h1>Edit Share</h1>

      {/* ERROR DISPLAY */}
      { error &&
        <p style={{color: "red"}}>{error}</p>
      }

      {/* FORM DISPLAY */}
			<ValidatedForm
				loading={loading}
				submit={(share_number, shate_to) =>
					handleSubmit(share_number, shate_to)
				}
			/>
		</div>
	)
}
