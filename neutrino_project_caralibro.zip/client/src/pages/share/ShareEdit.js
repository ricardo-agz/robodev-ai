import React, { useState, useEffect } from 'react';
import '../../App.css';
import { useParams, useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';
import useApi from '../../hooks/useApi';

import { CircularProgress } from '@mui/material';
import configData from '../../config.json'

export default function ShareEdit() {
  const navigate = useNavigate();
  const [editLoading, setEditLoading] = useState(false);
  const [editError, setEditError] = useState(null);
  const { id } = useParams();
  const {
    result: share,
    loading: shareLoading,
    error: fetchError,
    refresh
  } = useApi(`${configData.SERVER_URL}/shares/${id}`);

	const handleSubmit = (share_number, shate_to) => {
    setEditLoading(true);
    setEditError(null);
    axios.put(`${configData.SERVER_URL}/shares/${id}/edit`, 
    {
      share_number: share_number,
      shate_to: shate_to
    })
    .then(_res => {
      navigate(`/shares/${id}`)
    })
    .catch(err => {
      setEditError(err.response.data.message);
    })
    .then(_res => {
      setEditLoading(false);
    })
	};

	if (fetchError) {
		return <p style={{color: "red"}}>Error: {fetchError}</p>;
  } else if (shareLoading || !share) {
		return <CircularProgress />;
	} else {
		return (
			<div className='container'>
				<h1>Edit Share</h1>

        {/* ERROR DISPLAY */}
        { editError &&
          <p style={{color: "red"}}>{editError}</p>
        }

        {/* FORM DISPLAY */}
				<ValidatedForm
					model={share}
					loading={editLoading}
					submit={(share_number, shate_to) =>
						handleSubmit(share_number, shate_to)
					}
				/>
			</div>
		)
	}
}
