import React from 'react';
import '../../App.css';
import axios from 'axios';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Button, CircularProgress } from '@mui/material';
import useApi from '../../hooks/useApi';

import configData from '../../config.json'


export default function ShareShow(props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { result: share, loading, error, refresh } = useApi(`${configData.SERVER_URL}/shares/${id}`);

  /*
   * Delete share
   */
  function handleDelete() {
    axios.delete(`${configData.SERVER_URL}/shares/${id}`);
    axios.delete(`${configData.SERVER_URL}/shares/${id}`);
    navigate('/shares');
  }


  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !share) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <div className='row'>
          <h1 className='paddedRight'>Share {id}</h1>

          {/* EDIT */}
          <Button variant="outlined" style={{marginRight: 15}}
            onClick={() => navigate(`/shares/${id}/edit`)}>edit
          </Button>

          {/* DELETE */}
          <Button variant="contained" color="error" 
            onClick={handleDelete}>delete
          </Button>
        </div>

        <label>Share Number: {share.share_number}</label>
        <label>Shate To: {share.shate_to}</label>

        
      </div>
    );
  }
}
