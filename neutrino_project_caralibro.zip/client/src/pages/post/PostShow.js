import React from 'react';
import '../../App.css';
import axios from 'axios';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Button, CircularProgress } from '@mui/material';
import useApi from '../../hooks/useApi';

import configData from '../../config.json'


export default function PostShow(props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { result: post, loading, error, refresh } = useApi(`${configData.SERVER_URL}/posts/${id}`);

  /*
   * Delete post
   */
  function handleDelete() {
    axios.delete(`${configData.SERVER_URL}/posts/${id}`);
    axios.delete(`${configData.SERVER_URL}/posts/${id}`);
    navigate('/posts');
  }


  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !post) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <div className='row'>
          <h1 className='paddedRight'>Post {id}</h1>

          {/* EDIT */}
          <Button variant="outlined" style={{marginRight: 15}}
            onClick={() => navigate(`/posts/${id}/edit`)}>edit
          </Button>

          {/* DELETE */}
          <Button variant="contained" color="error" 
            onClick={handleDelete}>delete
          </Button>
        </div>

        <label>Content: {post.content}</label>

        
      </div>
    );
  }
}
