import React, { useState, useEffect } from 'react';
import '../../App.css';
import { useParams, useNavigate } from 'react-router-dom';
import ValidatedForm from './ValidatedForm';
import axios from 'axios';
import useApi from '../../hooks/useApi';

import { CircularProgress } from '@mui/material';
import configData from '../../config.json'

export default function PostEdit() {
  const navigate = useNavigate();
  const [editLoading, setEditLoading] = useState(false);
  const [editError, setEditError] = useState(null);
  const { id } = useParams();
  const {
    result: post,
    loading: postLoading,
    error: fetchError,
    refresh
  } = useApi(`${configData.SERVER_URL}/posts/${id}`);

	const handleSubmit = (content) => {
    setEditLoading(true);
    setEditError(null);
    axios.put(`${configData.SERVER_URL}/posts/${id}/edit`, 
    {
      content: content
    })
    .then(_res => {
      navigate(`/posts/${id}`)
    })
    .catch(err => {
      setEditError(err.response.data.message);
    })
    .then(_res => {
      setEditLoading(false);
    })
	};

	if (fetchError) {
		return <p style={{color: "red"}}>Error: {fetchError}</p>;
  } else if (postLoading || !post) {
		return <CircularProgress />;
	} else {
		return (
			<div className='container'>
				<h1>Edit Post</h1>

        {/* ERROR DISPLAY */}
        { editError &&
          <p style={{color: "red"}}>{editError}</p>
        }

        {/* FORM DISPLAY */}
				<ValidatedForm
					model={post}
					loading={editLoading}
					submit={(content) =>
						handleSubmit(content)
					}
				/>
			</div>
		)
	}
}
