import React from 'react';
import '../../App.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Button, ButtonGroup, CircularProgress } from '@mui/material';
import useApi from '../../hooks/useApi';
import configData from '../../config.json'

export default function Posts() {
  const { result: posts, loading, error, refresh } = useApi(`${configData.SERVER_URL}/posts`);
  const navigate = useNavigate();

  function handleDelete(id) {
    axios.delete(`${configData.SERVER_URL}/posts/${id}`);
    window.location.reload();
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  } else if (loading || !posts) {
    return <CircularProgress />;
  } else {
    return (
      <div className='container'>
        <h1>Posts</h1>
        <Button 
          variant={"contained"}
          onClick={() => navigate("/posts/new")}
        >
        New Post
        </Button>

        <ul>
        {posts.map((post, i) => (
          <div className="listItem" key={i}>
            <li key={i}>{post.content}</li>
            <ButtonGroup variant="outlined" size="small">
              <Button onClick={() => navigate(`/posts/${post._id}`)}>show</Button>
              <Button onClick={() => navigate(`/posts/${post._id}/edit`)}>edit</Button>
              <Button color="error" onClick={() => handleDelete(post._id)}>delete</Button>
            </ButtonGroup>
          </div>
        ))}
        </ul>
      </div>
    );
  };
};
