export { default as Posts } from './Posts';
export { default as PostShow } from './PostShow';
export { default as PostNew } from './PostNew';
export { default as PostEdit } from './PostEdit';
