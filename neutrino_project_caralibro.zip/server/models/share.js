const mongoose = require('mongoose');

const ShareSchema = new mongoose.Schema({
	share_number: {
		type: Number,
		required: true
	},
	shate_to: {
		type: String,
		required: true
	},
});

ShareSchema.set('toObject', { virtuals: true });
ShareSchema.set('toJSON', { virtuals: true });

const Share = mongoose.model('Share', ShareSchema);
module.exports = Share;
