const mongoose = require('mongoose');

const LikeSchema = new mongoose.Schema({
	like_count: {
		type: Number,
		required: true
	},
});

LikeSchema.set('toObject', { virtuals: true });
LikeSchema.set('toJSON', { virtuals: true });

const Like = mongoose.model('Like', LikeSchema);
module.exports = Like;
