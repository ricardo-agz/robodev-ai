const mongoose = require('mongoose');

const CommentSchema = new mongoose.Schema({
	text: {
		type: String,
		required: true
	},
});

CommentSchema.set('toObject', { virtuals: true });
CommentSchema.set('toJSON', { virtuals: true });

const Comment = mongoose.model('Comment', CommentSchema);
module.exports = Comment;
