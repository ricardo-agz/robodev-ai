const mongoose = require('mongoose');

const StorySchema = new mongoose.Schema({
	content: {
		type: String,
		required: true
	},
	content: {
		type: Boolean,
		required: true
	},
});

StorySchema.set('toObject', { virtuals: true });
StorySchema.set('toJSON', { virtuals: true });

const Story = mongoose.model('Story', StorySchema);
module.exports = Story;
