const express       = require('express');
const router        = express.Router();
module.exports      = router;

const UserController = require('../controllers/userController');
const PostController = require('../controllers/postController');
const CommentController = require('../controllers/commentController');
const LikeController = require('../controllers/likeController');
const ShareController = require('../controllers/shareController');
const StoryController = require('../controllers/storyController');


// Home
router.get('/', (_req, res) => {
  res.status(200).send({ message: 'Welcome to Neutrino!' });
});

// User
router.get('/users', UserController.index);
router.get('/users/:id', UserController.show);
router.post('/users', UserController.create);
router.put('/users/:id/edit', UserController.update);
router.delete('/users/:id', UserController.delete);

// Post
router.get('/posts', PostController.index);
router.get('/posts/:id', PostController.show);
router.post('/posts', PostController.create);
router.put('/posts/:id/edit', PostController.update);
router.delete('/posts/:id', PostController.delete);

// Comment
router.get('/comments', CommentController.index);
router.get('/comments/:id', CommentController.show);
router.post('/comments', CommentController.create);
router.put('/comments/:id/edit', CommentController.update);
router.delete('/comments/:id', CommentController.delete);

// Like
router.get('/likes', LikeController.index);
router.get('/likes/:id', LikeController.show);
router.post('/likes', LikeController.create);
router.put('/likes/:id/edit', LikeController.update);
router.delete('/likes/:id', LikeController.delete);

// Share
router.get('/shares', ShareController.index);
router.get('/shares/:id', ShareController.show);
router.post('/shares', ShareController.create);
router.put('/shares/:id/edit', ShareController.update);
router.delete('/shares/:id', ShareController.delete);

// Story
router.get('/storys', StoryController.index);
router.get('/storys/:id', StoryController.show);
router.post('/storys', StoryController.create);
router.put('/storys/:id/edit', StoryController.update);
router.delete('/storys/:id', StoryController.delete);

// Default response for any other request
router.use((_req, res) => {
  res.status(404).send({ message: "404 not found" });
});