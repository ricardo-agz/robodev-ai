const Share = require('../models/share');


const ShareController = {

  // REMOVE TO ENABLE PAGINATION
  index: async (req, res) => {
    try {
      const data = await Share.find()
      res.status(200).send(data);
    } catch (err) {
      res.status(400).send(err.message);
      console.log(err);
    }
  }, 

  // UNCOMMENT AND FOLLOW INSTRUCTIONS TO ENABLE PAGINATION
  /*
  index: async (req, res, next) => {
    const page = parseInt(req.query.page);
    const limit = parseInt(req.query.limit);
    const skipIndex = (page - 1) * limit;
    const results = {};

    try {
      results.results = await Share.find()
        .sort({ _id: 1 })
        .limit(limit)
        .skip(skipIndex)
        .exec();
      res.paginatedResults = results;
      next();
    } catch (e) {
      res.status(500).json({ message: "Error Occured" });
    }
  }, 
  */

  /* INSTRUCTIONS
  in server.js, replace:
    app.get('/shares', ShareController.index);

  with:
    app.get('/shares', ShareController.index, (req, res) => {
      res.json(res.paginatedResults.results);
    });
  */

  show: async (req, res) => {
    const { id } = req.params;
    try {
      const data = await Share.findById(id)
      res.status(200).send(data);
    } catch (err) {
      res.status(400).send(err.message);
      console.log(err);
    }
  },

  create: async (req, res) => {
		const { share_number, shate_to, } = req.body;
		const share = new Share({ share_number: share_number, shate_to: shate_to, });
    try {
      await share.save();
      res.status(200).send('data created!');
      console.log('Share created!');
    } catch (err) {
      res.status(500).send(err);
      console.log(err);
    }
  },

  update: async (req, res) => {
    const { id } = req.params;
    const data = await Share.findById(id);
    Share.findByIdAndUpdate(id, 
    {
			share_number: req.body.share_number,
			shate_to: req.body.shate_to,
    },
    (err, data) => {
      if (err) {
        res.status(500).send(err);
        console.log(err);
      } else {
        res.status(200).send(data);
        console.log('Share updated!');
      }
    })
  },

  delete: async (req, res) => {
    const { id } = req.params;
    const data = await Share.findById(id);
    try {
      Share.findByIdAndDelete(id).exec();
      res.status(200).send('Share deleted');
      console.log('Share deleted!');
    } catch (err) {
      res.status(400).send(err.message);
      console.log(err);
    }
  },



}

module.exports = ShareController;