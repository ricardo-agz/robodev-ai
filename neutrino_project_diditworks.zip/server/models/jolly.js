const mongoose = require('mongoose');

const JollySchema = new mongoose.Schema({
	name: {
		type: String,
		required: true
	},
});

JollySchema.set('toObject', { virtuals: true });
JollySchema.set('toJSON', { virtuals: true });

const Jolly = mongoose.model('Jolly', JollySchema);
module.exports = Jolly;
