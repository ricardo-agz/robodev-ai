const express       = require('express');
const router        = express.Router();
module.exports      = router;

const UserController = require('./controllers/UserController');
const NewController = require('./controllers/NewController');
const JollyController = require('./controllers/JollyController');
const AuthController = require('../controllers/authController');
const { untitledMiddleware } = require('./middlewares');


// Home
router.get('/', (_req, res) => {
  res.status(200).send({ message: 'Welcome to Neutrino!' });
});

router.get('/users', UserController.index);
router.get('/users/:id', UserController.show);
router.post('/users', UserController.create);
router.put('/users/:id', UserController.update);
router.delete('/users/:id', UserController.delete);

router.get('jhlkjhl', untitledMiddleware, NewController.hkjlh);
router.get('stuck', NewController.stuck);

router.get('/jollies', JollyController.index);
router.get('/jollies/:id', JollyController.show);
router.post('/jollies', JollyController.create);
router.put('/jollies/:id', JollyController.update);
router.delete('/jollies/:id', JollyController.delete);

// Auth
router.post('/auth/login', AuthController.login);
router.post('/auth/register', AuthController.register);

// Default response for any other request
router.use((_req, res) => {
  res.status(404).send({ message: "404 not found" });
});