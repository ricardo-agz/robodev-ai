const User = require('../models/user');
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
require('dotenv').config();

const untitledMiddleware = (req, res, next) => {
	    const data = await User.findOne({ });	    if (sdfg) {	    };	
}
module.exports = {
	untitledMiddleware
};