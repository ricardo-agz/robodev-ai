const Jolly = require('../models/jolly');

const JollyController = {
  
	/*
	 * index
	 * url: /jollies
	 */
	index: async (req, res) => {
		try {
	    const data = await Jolly.find({});
	    return res.status(200).send(data);
		} catch(e) {
			res.status(500).send({ message: `server error in JollyController index() : ${e}` });
		};
	},

	/*
	 * show
	 * url: /jollies/:id
	 * params: ['id']
	 */
	show: async (req, res) => {
		try {
			const { id } = req.params;
	    const data = await Jolly.findById(id);
	    return res.status(200).send(data);
		} catch(e) {
			res.status(500).send({ message: `server error in JollyController show() : ${e}` });
		};
	},

	/*
	 * create
	 * url: /jollies
	 */
	create: async (req, res) => {
		try {
	    const newData = await new Jolly({
	    }).save((err, data) => {
	        if (err) {
	            return res.status(500).send({ message: "Error creating new Jolly" });
	        };
	        return res.status(200).send({ message: "New Jolly was successfully created!" });
	    });
		} catch(e) {
			res.status(500).send({ message: `server error in JollyController create() : ${e}` });
		};
	},

	/*
	 * update
	 * url: /jollies/:id
	 * params: ['id']
	 */
	update: async (req, res) => {
		try {
			const { id } = req.params;
	    const newData = await Jolly.findByIdAndUpdate(id,
	    {
	    },
	    (err, data) => {
	        if (err) {
	            return res.status(500).send({ message: "Error updating Jolly" });
	        };
	        return res.status(200).send({ message: "Jolly was successfully updated!" });
	    });
		} catch(e) {
			res.status(500).send({ message: `server error in JollyController update() : ${e}` });
		};
	},

	/*
	 * delete
	 * url: /jollies/:id
	 * params: ['id']
	 */
	delete: async (req, res) => {
		try {
			const { id } = req.params;
	    const data = await Jolly.findByIdAndDelete(id,
	    (err, data) => {
	        if (err) {
	            return res.status(500).send({ message: "Error deleting Jolly" });
	        };
	        return res.status(200).send({ message: "Jolly was successfully deleted" });
	    });
		} catch(e) {
			res.status(500).send({ message: `server error in JollyController delete() : ${e}` });
		};
	},


}

module.exports = JollyController;