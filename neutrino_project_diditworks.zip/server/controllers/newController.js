
const NewController = {
  
	/*
	 * hkjlh
	 * url: jhlkjhl
	 */
	hkjlh: async (req, res) => {
		try {
		} catch(e) {
			res.status(500).send({ message: `server error in NewController hkjlh() : ${e}` });
		};
	},

	/*
	 * stuck
	 * url: stuck
	 */
	stuck: async (req, res) => {
		try {
		} catch(e) {
			res.status(500).send({ message: `server error in NewController stuck() : ${e}` });
		};
	},


}

module.exports = NewController;